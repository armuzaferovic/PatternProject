package model;

public class StatePlayoffs implements States{

    @Override
    public void nochImSpiel() {
        System.out.println("Sie sind in den Playoffs");
    }
}
