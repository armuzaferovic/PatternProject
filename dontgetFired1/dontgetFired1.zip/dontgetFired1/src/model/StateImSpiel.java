package model;

public class StateImSpiel implements States {
    @Override
    public void nochImSpiel() {
        System.out.println("Weitergehts!");
    }
}
