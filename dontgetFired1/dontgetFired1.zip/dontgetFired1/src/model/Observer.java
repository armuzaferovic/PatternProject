package model;

public abstract class Observer {
    protected Spiel sub;
    public abstract void update();
}
