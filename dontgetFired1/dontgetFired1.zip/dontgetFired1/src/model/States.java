package model;

public interface States {
    void nochImSpiel();
}
