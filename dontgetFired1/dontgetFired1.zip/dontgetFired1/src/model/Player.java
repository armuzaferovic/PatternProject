package model;

public interface Player {
	
	String print(char Type);
}
