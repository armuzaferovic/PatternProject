package model;

public class StateVerloren implements States {
    @Override
    public void nochImSpiel() {
        System.out.println("SIE SIND GEFEUERT");
    }
}
