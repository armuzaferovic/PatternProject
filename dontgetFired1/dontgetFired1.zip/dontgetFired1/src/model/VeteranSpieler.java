package model;

public class VeteranSpieler implements Player {

    @Override
    public String print(char Type) {
        return null;
    }
}
